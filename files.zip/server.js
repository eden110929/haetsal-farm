const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const srv = http.createServer(app);
const io = new Server(srv);
app.use(express.static(__dirname + '/public'));

const COLS = 8, ROWS = 10, DAY_REAL = 150, MAX_PLAYERS = 8, SEASON_DAYS = 7;
const LEVELS = [{c0:1,c1:6,r:4},{c0:1,c1:6,r:6},{c0:0,c1:7,r:6},{c0:0,c1:7,r:8},{c0:0,c1:7,r:10}];
const CROPS = {
  carrot:{days:2,regrow:0,seasons:[0,2,3]}, tomato:{days:4,regrow:2,seasons:[1]},
  pumpkin:{days:6,regrow:0,seasons:[2]},    pepper:{days:5,regrow:3,seasons:[1,2]},
  blueberry:{days:6,regrow:2,seasons:[1,2]}, cucumber:{days:3,regrow:0,seasons:[0,1]}
};
const seasonIdx = d => Math.floor((d - 1) / SEASON_DAYS) % 4;
const isOpen = (k, lv) => { const i = k % COLS, j = Math.floor(k / COLS), L = LEVELS[lv]; return i >= L.c0 && i <= L.c1 && j < L.r; };

function fresh() {
  const tiles = [];
  for (let k = 0; k < COLS * ROWS; k++) {
    const i = k % COLS, j = Math.floor(k / COLS);
    tiles.push({ t: 0, w: i >= 1 && i <= 6 && j < 4 && Math.random() < 0.3 ? 1 : 0, wa: 0, c: null });
  }
  return { tiles, day: 1, hour: 6, weather: 'sun', eggs: 1, fed: false, level: 0 };
}
let W = fresh();
const players = new Map(); // id -> {name,x,z,f,asleep}

function newDay(forced) {
  let revertN = 0, witherN = 0;
  W.tiles.forEach((st, k) => {
    if (st.c && st.wa) st.c.age = Math.min(CROPS[st.c.type].days, st.c.age + 1);
    if (st.t && !st.c) { st.t = 0; revertN++; }
    if (isOpen(k, W.level) && !st.t && !st.c && !st.w && Math.random() < 0.12) st.w = 1;
    st.wa = 0;
  });
  W.day++; W.hour = 6;
  const oldS = seasonIdx(W.day - 1), newS = seasonIdx(W.day), seasonChanged = oldS !== newS;
  if (seasonChanged) W.tiles.forEach(st => { if (st.c && CROPS[st.c.type].seasons.indexOf(newS) < 0) { st.c = null; witherN++; } });
  W.eggs = Math.min(6, W.eggs + (W.fed ? 3 : 1)); W.fed = false;
  W.weather = Math.random() < 0.2 ? (newS === 3 ? 'snow' : 'rain') : 'sun';
  if (W.weather === 'rain') W.tiles.forEach(st => { if (st.t) st.wa = 1; });
  players.forEach(p => { p.asleep = false; });
  io.emit('newday', Object.assign({ forced: !!forced, revertN, witherN, seasonChanged }, W));
}
function checkSleep() {
  if (!players.size) return;
  let n = 0; players.forEach(p => { if (p.asleep) n++; });
  if (n === players.size) newDay(false);
  else io.emit('sleepers', { n, total: players.size });
}

// 서버가 시간을 관리 (접속자가 있을 때만 흐름)
setInterval(() => {
  if (!players.size) return;
  W.hour += 18 / DAY_REAL;
  if (W.hour >= 24) newDay(true);
}, 1000);
setInterval(() => { if (players.size) io.emit('time', { day: W.day, hour: W.hour, weather: W.weather }); }, 2000);

io.on('connection', socket => {
  socket.on('join', m => {
    if (players.size >= MAX_PLAYERS && !players.has(socket.id)) { socket.emit('full'); socket.disconnect(); return; }
    const name = String((m && m.name) || '농부').slice(0, 8);
    const me = { name, x: 0, z: -7.8, f: 0, asleep: false };
    const others = [...players].map(([id, p]) => ({ id, name: p.name, x: p.x, z: p.z, f: p.f }));
    players.set(socket.id, me);
    socket.emit('init', { id: socket.id, world: W, players: others });
    socket.broadcast.emit('join', { id: socket.id, name, x: me.x, z: me.z, f: me.f });
  });

  socket.on('move', m => {
    const p = players.get(socket.id);
    if (!p || !m || !Number.isFinite(m.x) || !Number.isFinite(m.z) || !Number.isFinite(m.f)) return;
    p.x = Math.max(-40, Math.min(40, m.x)); p.z = Math.max(-40, Math.min(40, m.z)); p.f = m.f;
    socket.broadcast.emit('move', { id: socket.id, x: p.x, z: p.z, f: p.f });
  });

  // 밭 행동: 서버가 검사해서 "먼저 한 사람"만 성공
  socket.on('tile', (m, cb) => {
    if (typeof cb !== 'function' || !players.has(socket.id) || !m) return;
    const st = W.tiles[m.k];
    if (!st) return;
    let ok = false, err = '친구가 먼저 했어요!', upd = [{ k: m.k, st }];
    if (!isOpen(m.k, W.level)) err = '아직 풀숲이에요.';
    else switch (m.kind) {
      case 'pull': if (st.w) { st.w = 0; ok = true; } break;
      case 'till': if (!st.t && !st.w && !st.c) { st.t = 1; ok = true; } break;
      case 'water': if (st.t && !st.wa) { st.wa = 1; ok = true; } break;
      case 'untill': if (st.t && !st.c) { st.t = 0; st.wa = 0; ok = true; } break;
      case 'dig': if (st.c) { st.c = null; ok = true; } break;
      case 'plant': {
        const d = CROPS[m.type];
        if (d && st.t && !st.c && !st.w && d.seasons.indexOf(seasonIdx(W.day)) >= 0) { st.c = { type: m.type, age: 0 }; ok = true; }
        break;
      }
      case 'harvest': {
        const c = st.c;
        if (c && c.age >= CROPS[c.type].days) {
          if (CROPS[c.type].regrow) c.age = CROPS[c.type].days - CROPS[c.type].regrow; else st.c = null;
          ok = true;
        }
        break;
      }
      case 'bomb': {
        upd = [];
        (Array.isArray(m.ks) ? m.ks.slice(0, 8) : []).forEach(k => {
          const s2 = W.tiles[k];
          if (s2 && isOpen(k, W.level) && s2.t && !s2.wa) { s2.wa = 1; upd.push({ k, st: s2 }); }
        });
        ok = upd.length > 0;
        if (!ok) upd = [{ k: m.k, st }];
        break;
      }
    }
    cb(ok ? { ok: true, upd } : { ok: false, err, upd });
    if (ok) socket.broadcast.emit('tile', { upd });
  });

  socket.on('coop', kind => {
    if (kind === 'egg') W.eggs = 0;
    else if (kind === 'feed') W.fed = true;
    else return;
    socket.broadcast.emit('coop', { eggs: W.eggs, fed: W.fed, level: W.level });
  });
  socket.on('expand', lv => {
    if (lv !== W.level + 1 || lv >= LEVELS.length) return;
    W.level = lv;
    socket.broadcast.emit('coop', { eggs: W.eggs, fed: W.fed, level: W.level });
  });
  socket.on('sleep', () => { const p = players.get(socket.id); if (p) { p.asleep = true; checkSleep(); } });

  socket.on('disconnect', () => {
    if (!players.delete(socket.id)) return;
    io.emit('leave', socket.id);
    checkSleep();
  });
});

const PORT = process.env.PORT || 3000;
srv.listen(PORT, () => console.log('농장 서버 실행 중: http://localhost:' + PORT));
